from django.db import models

# Create your models here.

#create state choices 
STATE_CHOICES=(   
('Andhra Pradesh','Andhra Pradesh'),
('Arunachal Pradesh','Arunachal Pradesh'),
('Assam','Assam'),
('Bihar','Bihar'),
('Chhatisgarh','Chhatisgarh'),
('Delhi','Delhi'),
('Goa','Goa'),
('Gujrat','Gujarat'),
('Haryana','Haryana'),
('Himachal Pradesh','Himachal Pradesh'),
('Jharakhand','Jharakhand'),
('Karnataka','Karnataka'),
('Kerala','Kerala'),
('Madhya Pradesh','Madhya Pradesh'),
('Maharashtra','Maharashtra'),
('Manipur','Manipur'),
('Mizuram','Mizuram'),
('Nagaland','Nagaland'),
('Odisha','Odisha'),
('Panjab','Panjab'),
('Rajastan','Rajastan'),
('Sikkim','Sikkim'),
('Tamilnadu','Tamilnadu'),
('Telangana','Telangana'),
('Tripura','Tripura'),
('Uttar Pradesh','Uttar Pradesh'),
('Uttarakhand','Uttarakhand'),
('West Bengal','West Bengal')
)

#create gender choices
gender_choices=[('Male','Male'),
('Female','Female')]

#create city choices
job_city_choices=(('Banglore','Banglore'),
('Chennai','Chennai'),
('Hyderabad','Hyderabad'),
('Pune','Pune'),
('Mumbai','Mumbai'),
('Nagpur','Nagpur'),
('kolkata','Kolkata'),
('Delhi','Delhi'),
('Agra','Agra'),
('Jaipur','Jaipur'),
('Vizag','Vizag'),
('Nashik','Nashik'),
('Kochi','Kochi'),
('Coimbatur','Coimbatur'),
('Thane','Thane'),
('Madurai','Madurai'),
('Vadodara','Vadodara'))

# create Resume class into a model form 
class Resume(models.Model):
    
    #create all neccesary variables for the model form
    name=models.CharField(max_length=70)
    dob=models.DateField(auto_now=False,auto_now_add=False)
    gender=models.CharField(choices=gender_choices,max_length=20)
    locality=models.CharField(max_length=100)
    city=models.CharField(max_length=50)
    pin=models.PositiveIntegerField()
    state=models.CharField(choices=STATE_CHOICES, max_length=40)
    mobile=models.IntegerField()
    email=models.EmailField()
    job_city=models.CharField(choices=job_city_choices,max_length=100)
    profile_image=models.ImageField(upload_to='profileimg', blank=True)
    my_file=models.FileField(upload_to='doc',blank=True)
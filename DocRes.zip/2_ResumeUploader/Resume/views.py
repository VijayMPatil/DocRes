from django.http.response import HttpResponse, HttpResponseRedirect
from django.shortcuts import render
from django.http import request # import request from http 
from .forms import ResumeForms # import resumeform from form.py 
from .models import Resume #import Resume class from models.py 
from django.views import View # import view file
#from .admin import ResumeModelAdmin

class HomeView(View):
    def get(self, request):
        form=ResumeForms()
        candidates=Resume.objects.all() # fetch all variables in 'Resume class' model
        return render(request,'home.html',{'candidates':candidates,'form':form})

    def post(self,request):
        form=ResumeForms(request.POST,request.FILES)
        if form.is_valid():
            form.save()
        return render(request,'home.html',{'form':form}) 

class CandidatesView(View):
    def get(self, request, pk):
        candidate=Resume.objects.get(pk=pk) # set primary key
        return render(request,'candidate.html',{'candidate':candidate})    
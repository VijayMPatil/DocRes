from django.contrib import admin
from .models import Resume

@admin.register(Resume) # Use decorator 
class ResumeModelAdmin(admin.ModelAdmin):
    
    # Display all variables form the model form
    list_display=['id','name','dob','gender','locality','city','pin','state','mobile',
                   'email','job_city','profile_image','my_file']

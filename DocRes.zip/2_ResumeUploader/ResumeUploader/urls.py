
from django.contrib import admin
from django.urls import path
from Resume import views # import neccesary functions and data from the view.py file

urlpatterns = [
    path('admin/', admin.site.urls), # set admin page
    path('', views.HomeView.as_view(), name='home'),# fetch the function name from view 
    path('<int:pk>',views.CandidatesView.as_view(),name='candidate'), # fetch the function the view

]

# I have used for fetching the data i.e images & pdfs  
from django.conf import settings
from django.conf.urls.static import static
if settings.DEBUG:
        urlpatterns += static(settings.MEDIA_URL,
                              document_root=settings.MEDIA_ROOT)
